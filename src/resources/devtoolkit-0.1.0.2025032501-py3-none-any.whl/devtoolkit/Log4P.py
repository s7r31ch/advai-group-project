import os
from datetime import datetime
import sys

class Log4P:
    TIMESTAMP_REGEX = "%Y-%m-%d %H:%M:%S"
    INFO = "Info"
    WARNING = "Warning"
    ERROR = "Error"
    DEBUG = "Debug"
    
    def __init__(self,
                 enable_level = False,
                 enable_timestamp = False,
                 enable_source = False,
                 enable_log_file = False,
                 **kwargs):
        try:  
            self.enable_level = enable_level
            self.enable_timestamp = enable_timestamp
            self.enable_source = enable_source
            self.enable_log_file = enable_log_file
            if enable_timestamp:
                if "timestamp_regex" in kwargs: self.timestamp_regex = kwargs["timestamp_regex"]
                else: self.timestamp_regex = self.TIMESTAMP_REGEX
            if enable_source:
                if "source" in kwargs: self.source = kwargs["source"]
                else: raise Log4PException(message_raw = "Source enabled but source undefined!",
                                           enable_level = self.enable_level,
                                           enable_timestamp = self.enable_timestamp,
                                           enable_source = self.enable_source)
            if enable_log_file:
                if "log_file_path" in kwargs:
                    self.log_file_path = kwargs["log_file_path"]
                    if os.path.exists(self.log_file_path): print("Log file already exists, old file will be overwritten!")
                    self.log_file = open(self.log_file_path, "w")
                else: raise Log4PException(message_raw = "Log file enabled but log file path undefined!",
                                           enable_level = self.enable_level,
                                           enable_timestamp = self.enable_timestamp,
                                           enable_source = self.enable_source,
                                           level = Log4P.ERROR)
        except Log4PException as log4PException: log4PException.output()
    
    def info(self,
            message_raw):
        message = message_raw
        if self.enable_source: message = f"[{self.source}]: {message}"
        if self.enable_timestamp:
            timestamp = datetime.now().strftime(self.timestamp_regex)
            message = f"[{timestamp}]{message}"
        if self.enable_level: 
            message = f"[{Log4P.INFO}]{message}"
        if self.enable_log_file: self.log_file.write(f"{message}\n")
        print(message)
    
    def warning(self,
            message_raw):
        message = message_raw
        if self.enable_source: message = f"[{self.source}]: {message}"
        if self.enable_timestamp:
            timestamp = datetime.now().strftime(self.timestamp_regex)
            message = f"[{timestamp}]{message}"
        if self.enable_level: 
            message = f"[{Log4P.WARNING}]{message}"
        if self.enable_log_file: self.log_file.write(f"{message}\n")
        print(message)
    
    def error(self,
            message_raw):
        message = message_raw
        if self.enable_source: message = f"[{self.source}]: {message}"
        if self.enable_timestamp:
            timestamp = datetime.now().strftime(self.timestamp_regex)
            message = f"[{timestamp}]{message}"
        if self.enable_level: 
            message = f"[{Log4P.ERROR}]{message}"
        if self.enable_log_file: self.log_file.write(f"{message}\n")
        print(message)
    
    def debug(self,
            message_raw):
        message = message_raw
        if self.enable_source: message = f"[{self.source}]: {message}"
        if self.enable_timestamp:
            timestamp = datetime.now().strftime(self.timestamp_regex)
            message = f"[{timestamp}]{message}"
        if self.enable_level: 
            message = f"[{Log4P.DEBUG}]{message}"
        if self.enable_log_file: self.log_file.write(f"{message}\n")
        print(message)
            
    def destroy(self):
        if self.enable_log_file: self.log_file.close()
        
    def enable_level(self,
                    **kwargs):
        try:
            if self.enable_level: raise Log4PException(message_raw = "Level already enabled!",
                                                      enable_level = self.enable_level,
                                                      enable_timestamp = self.enable_timestamp,
                                                      enable_source = self.enable_source)
            if "level" in kwargs: self.level = kwargs["level"]
            else: self.level = Log4P.INFO 
            self.enable_level = True
            return self
        except Log4PException as log4PException: log4PException.output()
            
    def disable_level(self):
        try:
            if not self.enable_level: raise Log4PException(message_raw = "Level already disabled!",
                                                          enable_level = self.enable_level,
                                                          enable_timestamp = self.enable_timestamp,
                                                          enable_source = self.enable_source)
            self.enable_level = False
            return self
        except Log4PException as log4PException: log4PException.output()
                
    def enable_timestamp(self,
                         **kwargs):
        try:
            if self.enable_timestamp: raise Log4PException(message_raw = "Timestamp already enabled!",
                                                           enable_level = self.enable_level,
                                                           enable_timestamp = self.enable_timestamp,
                                                           enable_source = self.enable_source)
            if "timestamp_regex" in kwargs: self.timestamp_regex = kwargs["timestamp_regex"]
            else: self.timestamp_regex = self.TIMESTAMP_REGEX
            self.timestamp = True
            return self
        except Log4PException as log4PException: log4PException.output()
        
    def disable_timestamp(self):
        try:
            if not self.enable_timestamp: raise Log4PException(message_raw = "Timestamp already disabled!",
                                                               enable_level = self.enable_level,
                                                               enable_timestamp = self.enable_timestamp,
                                                               enable_source = self.enable_source)
            self.timestamp = False
            return self
        except Log4PException as log4PException: log4PException.output()
    
    def enable_source(self,
                      **kwargs):
        try:
            if self.enable_source: raise Log4PException(message_raw = "Source already enabled!",
                                                        enable_level = self.enable_level,
                                                        enable_timestamp = self.enable_timestamp,
                                                        enable_source = self.enable_source)
            if "source" in kwargs:
                self.enable_source = True
                self.source = kwargs["source"]
                return self
            else: raise Log4PException(message_raw = "Source enabled but undefined!",
                                       enable_level = self.enable_level,
                                       enable_timestamp = self.enable_timestamp,
                                       enable_source = self.enable_source)
        except Log4PException as log4PException: log4PException.output()
    
    def disable_source(self):
        try:
            if not self.enable_source: raise Log4PException(message_raw = "Source already disabled!",
                                                            enable_level = self.enable_level,
                                                            enable_timestamp = self.enable_timestamp,
                                                            enable_source = self.enable_source)
            self.source = False
            return self
        except Log4PException as log4PException: log4PException.output()
    
    def enable_log_file(self, 
                        **kwargs):
        try:
            if self.enable_log_file: raise Log4PException(message_raw = "Log file already enabled!",
                                                          enable_level = self.enable_level,
                                                          enable_timestamp = self.enable_timestamp,
                                                          enable_source = self.enable_source)
            if "log_file_path" in kwargs:
                self.enable_log_file = True
                self.log_file_path = kwargs["log_file_path"]
                if os.path.exists(self.log_file_path): print("Log file already exists, old file will be overwritten!")
                self.log_file = open(self.log_file_path, "w")
                return self
            else: raise Log4PException(message_raw = "Log file enabled but log file path undefined!",
                                       enable_level = self.enable_level,
                                       enable_timestamp = self.enable_timestamp,
                                       enable_source = self.enable_source)
        except Log4PException as log4PException: log4PException.output()
    
    def disable_log_file(self):
        try:
            if not self.enable_log_file: raise Log4PException(message_raw = "Source already disabled!",
                                                              enable_level = self.enable_level,
                                                              enable_timestamp = self.enable_timestamp,
                                                              enable_source = self.enable_source)
            else: 
                self.enable_log_file = False
                return self
        except Log4PException as log4PException: log4PException.output()
    
    def set_timestamp_regex(self,
                            timestamp_regex):
        try:
            if not self.enable_timestamp: raise Log4PException(message_raw = "Timestamp regex can only be set when timestamp enabled, but now disabled!",
                                                               enable_level = self.enable_level,
                                                               enable_timestamp = self.enable_timestamp,
                                                               enable_source = self.enable_source)
            self.timestamp_regex = timestamp_regex        
            return self
        except Log4PException as log4PException: log4PException.output()
    
    def set_source(self,
                   source):
        try:
            if not self.enable_source: raise Log4PException(message_raw = "Source can only be set when enabled, but now disabled!",
                                                            enable_level = self.enable_level,
                                                            enable_timestamp = self.enable_timestamp,
                                                            enable_source = self.enable_source)
            self.source = source
            return self
        except Log4PException as log4PException: log4PException.output()
    
    def set_log_file_path(self,
                          log_file_path):
        try:
            if not self.enable_log_file: raise Log4PException(message_raw = "Log file path can only be set when log file enabled, but now disabled!",
                                                              enable_level = self.enable_level,
                                                              enable_timestamp = self.enable_timestamp,
                                                              enable_source = self.enable_source)
            self.log_file_path = log_file_path
            self.log_file.close()
            self.log_file = open(self.log_file_path, "w")
            return self
        except Log4PException as log4PException: log4PException.output()

class Log4PException(Exception):
    TIMESTAMP_REGEX = "%Y-%m-%d %H:%M:%S"
    def __init__(self,
                 message_raw,
                 enable_level = False,
                 enable_timestamp =  False,
                 enable_source = False,
                 **kwargs
                 ):
        self.message = message_raw
        self.level = Log4P.WARNING
        self.source = "Log4PException"
        if "logger" in kwargs:
            self.enable_level = kwargs["logger"].enable_level
            self.enable_timestamp = kwargs["logger"].enable_timestamp
            self.enable_source = kwargs["logger"].enable_source
        if enable_source: 
            if "source" in kwargs: self.source = kwargs["source"]
            self.message = f"[{self.source}]: {self.message}"
        if enable_timestamp: 
            if "timestamp_regex" in kwargs: self.timestamp = kwargs["timestamp_regex"]
            else: self.timestamp = datetime.now().strftime(self.TIMESTAMP_REGEX)
            self.message = f"[{self.timestamp}]{self.message}"
        if enable_level: 
            if "level" in kwargs: self.level = kwargs["level"]
            self.message = f"[{self.level}]{self.message}"
        super().__init__(f"{self.message}")
    
    def output(self):
        print(self.message)
        if self.level == Log4P.ERROR: sys.exit("Program crashed due to an error.")